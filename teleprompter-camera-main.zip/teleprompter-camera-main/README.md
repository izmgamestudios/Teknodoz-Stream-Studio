# Teleprompter Camera

Bir tane prompt olacak yani o... prompt. Printer pardon printer. Video izlerken okuyabileceğim akış olabilecek podcast yapayken izlerken karşıtı diyalogları input edebileceğim Word dosyası pan- pana kopyalaması text dosyası gibi inputlarla sohbetin diyaloglarını repliklerine girebileceğiz. Kamera açacak uygulama, kamera da beni çekerken ben merceğe ekrana bakıcam ve yazıyı okuyabileceğim sıra sıra sağ ve sol A ve B kişisi gibi ekranda iki farklı diyaloglar yazacak. Bir inputlayabileceğim bir podcast kamera izleme yazı okuma ekranı yapan bir uygulama olsun

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://teleprompter-camera.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/4239c1f5-ad3d-41e3-ae3c-79057b098f67).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
